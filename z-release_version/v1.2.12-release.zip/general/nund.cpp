#include "nund.h"

const BnmlFast NuNd::bf = BnmlFast();
