/*
code developed by
    Rong-Qiang He (rqhe@ruc.edu.cn, RUC, China)
date 2013 - 2017
*/

#include "bnmlfast.h"
#include "onb.h"

const BnmlFast Onb::bf = BnmlFast();
const Int Onb::max_ns = 32;				// max of valid ns
